from tgbot.syncbot import SyncBot
instances: dict[int, SyncBot] = {}
